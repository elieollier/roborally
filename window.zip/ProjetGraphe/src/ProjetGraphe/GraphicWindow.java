package ProjetGraphe;

import java.awt.BorderLayout;	
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Panel;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class GraphicWindow extends JFrame {

	private static final long serialVersionUID = 1L;

	public GraphicWindow() {
		super("~ RoboRally en multijoueur ! ~");
		this.setIconImage(Toolkit.getDefaultToolkit().getImage("logo.png"));  
		this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // En cas de fermeture de la fenetre, coupe l'execution du programme
		//this.setSize(1200, 650); // Taille de la fenetre
		this.setExtendedState(this.MAXIMIZED_BOTH); // Taille de la fenetre = Plein Ecran
		this.setLocationRelativeTo(null); // Centre la fenetre
		
		JPanel contentPane = (JPanel) this.getContentPane();
		contentPane.setLayout(new BorderLayout());
		
		//-- MENU --\\	
		this.setJMenuBar( creationMenu() );
		
		//-- CENTER --\\
		contentPane.add( creationPlateau(), BorderLayout.CENTER);
		
		//-- SOUTH --\\
		contentPane.add( new JCheckBox("STATISTIQUES        |        TEMPS JOUE : 10min 30        |"
				+ "        Nombre de joueurs : n        "), BorderLayout.SOUTH);
	
		//-- WEST --\\
		contentPane.add( creationCoteGauche(), BorderLayout.WEST);
	}
	
	private JPanel creationPlateau() {
		JPanel jpanel = new JPanel(new GridLayout(10,10,0,0));
		
		for (int i=0; i < 100 ;i++) {
			jpanel.add(new JLabel(new ImageIcon("t.jpg"), JLabel.CENTER));
		}
		
		
		return jpanel;
	}
	
	
	private JPanel creationCoteGauche() {
		/*-- Le c�t� gauche est compos� de 2 parties : 
				1) Le profil du Bot
				2) Ses cartes --*/
		JPanel jpanelCoteGauche = new JPanel(new GridLayout(1, 1, 0, 0));
		
		// Le profil \\
			//JPanel jpanelProfil = new JPanel(new GridLayout(1, 2, 0, 0));
		
		//jpanelCoteGauche.add(jpanelProfil);
		
		// Les cartes \\
			String[] listeDesCartes = {"carte.png","carte3.png","carte2.png",
					"carte3.png","carte.png","carte2.png",
					"carte.png","carte3.png","carte2.png"};
			
			JPanel jpanelCartes = new JPanel(new GridLayout(listeDesCartes.length/3, 3, 0, 0));
			
			for (int i=0; i < listeDesCartes.length ;i++) {
				JButton bouton = new JButton(new ImageIcon(listeDesCartes[i]));
					// On enl�ve le fond et le contour du bouton moche
					bouton.setContentAreaFilled(false);
					bouton.setBorderPainted(false);
				jpanelCartes.add(bouton);
			}
		jpanelCoteGauche.add(jpanelCartes);
		
		return jpanelCoteGauche;
		
	}
	
	
	private JMenuBar creationMenu() {
		JMenuBar barreDeMenu = new JMenuBar();
		
		JMenu options = new JMenu("Menu des Options du jeu");
		barreDeMenu.add(options);
			
			JMenuItem bruits = new JMenuItem("Couper les Bruitages et la Musique");
			bruits.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					JOptionPane.showMessageDialog(GraphicWindow.this, "Les bruits et les musiques ont bien �t� coup�es.");
				}
			} );
			options.add(bruits);
			
			
		JMenu credits = new JMenu("Les Cr�dits sans lesquels ce jeu ne serait pas possible");
		barreDeMenu.add(credits);
			credits.add(new JMenuItem("Cr�ation Originelle"));
			credits.add(new JMenuItem("Musiques"));
			credits.add(new JMenuItem("Images"));
			
		return barreDeMenu;
	}
		
	
	
	public static void main(String[] args) {
		GraphicWindow window = new GraphicWindow();
		window.setVisible(true);

	}

}
