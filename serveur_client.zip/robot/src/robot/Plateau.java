package robot;

import java.util.List;
import java.util.ArrayList;

public class Plateau {
	private int[][] matriceDesCases;
	private int[][] matriceDesRobots;
	private List<Joueur> listeJoueurs;
	
	private static int tailleDuPlateau = 12;
	
	public Plateau() {
		listeJoueurs = new ArrayList<Joueur>();
		
		matriceDesCases = new int[tailleDuPlateau][tailleDuPlateau];
		matriceDesRobots = new int[tailleDuPlateau][tailleDuPlateau];
		
		for(int i = 0; i < tailleDuPlateau; i++){
			matriceDesCases[i] = new int[tailleDuPlateau]; 
			matriceDesRobots[i]= new int[tailleDuPlateau];
		}
	}

	public static int getTailleDuPlateau() {
		return tailleDuPlateau;
	}
	
	
//	public void deplacement(Robot robot, CarteDeplacement carte) {
//		int x = robot.getX();
//		int y = robot.getY();
//		matriceDesRobots[x][y] = null;
//
//		switch (robot.getOrientation) {
//		case haut:
//	           y = y - carte.getNbPas();
//	           break;
//		case bas:
//    			y = y + carte.getNbPas();
//    			break;
	
//		case gauche:
//    			x = x + carte.getNbPas();
//   			break;
//		case droite:
//				x = x - carte.getNbPas();
//				break;
//	           
//	      default:
//	           System.err.println("ERREUR : Orientation du robot incorrecte");
//	           break;
//		}
//		if (!(tailleDuPlateau > x >= 0 && tailleDuPlateau > y >= 0)) {
//			delete robot
//		}
//		else {
//			Est-ce qu'il y a un robot dans cette case ?
//         
//			robot.setX();
//			robot.setY();
//			ajout du robot � la matrice des robots
//		}
//	}
   
 
//	public void afficheMatriceRobots() {
//		String tmp;
//		 for(int i = 0; i < matriceDesRobots.length; i++){
//			 tmp = "";
//			for(int j = 0; j < matriceDesRobots[i].length; j++){
//				if (matriceDesRobots[i][j] instanceof Robot)
//					tmp += "R \t";
//				else
//					tmp += "  \t";
//			}
//		 System.out.print(tmp);
//		 }
//	}
}
	
